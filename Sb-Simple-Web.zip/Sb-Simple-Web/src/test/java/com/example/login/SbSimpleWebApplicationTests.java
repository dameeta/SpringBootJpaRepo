package com.example.login;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbSimpleWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
