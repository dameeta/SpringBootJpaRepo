package com.example.login.entity;

public interface UserDetails {

}
