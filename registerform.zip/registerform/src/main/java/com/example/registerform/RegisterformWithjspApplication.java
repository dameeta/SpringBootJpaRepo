package com.example.registerform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegisterformWithjspApplication {

	public static void main(String[] args) {

		SpringApplication.run(RegisterformWithjspApplication.class, args);
		System.out.println("Hello in Register form");
	}

}
