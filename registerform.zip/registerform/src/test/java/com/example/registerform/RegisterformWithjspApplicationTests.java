package com.example.registerform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegisterformWithjspApplicationTests {

	@Test
	void contextLoads() {
	}

}
