package com.sample.onetoone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaWithOneToOneexampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
