package com.sample.onetoone.service;

import com.sample.onetoone.entity.Person;
import com.sample.onetoone.repository.PersonRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PersonService {

 @Autowired
private PersonRepository personRepository;

public List<Person> getAllPersons()
{
    return this.personRepository.findAll();

}

public  Person getPersonById(Long id)
{
    return this.personRepository.findById(id).get();
}
public Person savePerson(Person person)
{
    return this.personRepository.save(person);
}

}
