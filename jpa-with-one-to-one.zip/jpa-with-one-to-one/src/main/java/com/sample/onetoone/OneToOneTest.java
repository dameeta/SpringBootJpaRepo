package com.sample.onetoone;

import com.sample.onetoone.entity.Person;
import com.sample.onetoone.entity.Profile;
import com.sample.onetoone.service.PersonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.time.LocalDate;

@SpringBootApplication
public class OneToOneTest  implements CommandLineRunner {
    @Autowired
    private PersonService personService;
    public static void main(String[] args) {

    SpringApplication.run(OneToOneTest.class, args);
}

    public void run(String args[]) throws Exception{

        Profile profile1=new Profile("http://linkedin.com/in/surendarkrishnamurthy",
                LocalDate.parse("2019-02-23"),LocalDate.parse("2023-05-19"));
        Person person=new Person("Surendar",25,profile1);

        Person savedPerson=personService.savePerson(person);
        System.out.println("Person Saved Successfully....");
        System.out.println(String.format("Saved Persons:\nName: %s \nAge: %s \nProfile Link:%s\n\n",

                savedPerson.getPerson_name(),savedPerson.getAge(),savedPerson.getProfile().getProfileLink()));

        Person personReceived= personService.getPersonById(savedPerson.getId());
        System.out.println(String.format("Searched persons are:\nName:%s \nAge: %s \nProfile Link: %s",

                personReceived.getPerson_name(),personReceived.getAge(),savedPerson.getProfile().getProfileLink()));

    }
}
