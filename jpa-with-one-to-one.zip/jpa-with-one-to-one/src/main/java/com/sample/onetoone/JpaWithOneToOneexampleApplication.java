package com.sample.onetoone;

import com.sample.onetoone.entity.Person;
import com.sample.onetoone.entity.Profile;
import com.sample.onetoone.repository.PersonRepository;
import com.sample.onetoone.service.PersonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.time.LocalDate;

@SpringBootApplication
public class JpaWithOneToOneexampleApplication {


	public static void main(String[] args) {


		SpringApplication.run(JpaWithOneToOneexampleApplication.class, args);
	}
}
