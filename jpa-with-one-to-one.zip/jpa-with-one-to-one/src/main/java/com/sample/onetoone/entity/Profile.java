package com.sample.onetoone.entity;


import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name="profile")
public class Profile {

    @Id
    @GeneratedValue
    @Column(name="profile_id")
        private Long id;
    @Column(name="profile_link")
    private String profileLink;
    @Column(name="started_date")
    private LocalDate startedDate;
    @Column(name="last_updated")
    private LocalDate last_updatedDate;

    public Profile() {
    }

    public Profile(String profileLink, LocalDate startedDate, LocalDate last_updatedDate) {
    super();
        this.profileLink = profileLink;
        this.startedDate = startedDate;
        this.last_updatedDate = last_updatedDate;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getProfileLink() {
        return profileLink;
    }

    public void setProfileLink(String profileLink) {
        this.profileLink = profileLink;
    }

    public LocalDate getStartedDate() {
        return startedDate;
    }

    public void setStartedDate(LocalDate startedDate) {
        this.startedDate = startedDate;
    }

    public LocalDate getLast_updatedDate() {
        return last_updatedDate;
    }

    public void setLast_updatedDate(LocalDate last_updatedDate) {
        this.last_updatedDate = last_updatedDate;
    }
}
