package com.sample.onetoone.service;

import com.sample.onetoone.entity.Profile;
import com.sample.onetoone.repository.ProfileRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProfileService {
    @Autowired
private ProfileRepository profileRepository;

    public List<Profile> getAllPersons()
    {
        return this.profileRepository.findAll();

    }
    public Profile getPersonsById(Long id)
    {
        return this.profileRepository.findById(id).get();
    }
}
